﻿Public Class Form1

    Dim num1 As Integer
    Dim num2 As Integer
    Dim Answer As Integer
    Dim multiply As Boolean = False
    Dim add As Boolean = False
    Dim take As Boolean = False
    Dim divid As Boolean = False

    Private Sub value1_Click(sender As Object, e As EventArgs) Handles value1.Click
        If Output.Text <> "0" Then
            Output.Text += "1"
        Else
            Output.Text = "1"
        End If

    End Sub

    Private Sub value2_Click(sender As Object, e As EventArgs) Handles value2.Click
        If Output.Text <> "0" Then
            Output.Text += "2"
        Else
            Output.Text = "2"
        End If

    End Sub

    Private Sub value3_Click(sender As Object, e As EventArgs) Handles value3.Click
        If Output.Text <> "0" Then
            Output.Text += "3"
        Else
            Output.Text = "3"
        End If

    End Sub

    Private Sub value4_Click(sender As Object, e As EventArgs) Handles value4.Click
        If Output.Text <> "0" Then
            Output.Text += "4"
        Else
            Output.Text = "4"
        End If

    End Sub

    Private Sub value5_Click(sender As Object, e As EventArgs) Handles value5.Click
        If Output.Text <> "0" Then
            Output.Text += "5"
        Else
            Output.Text = "5"
        End If

    End Sub

    Private Sub value6_Click(sender As Object, e As EventArgs) Handles value6.Click
        If Output.Text <> "0" Then
            Output.Text += "6"
        Else
            Output.Text = "6"
        End If

    End Sub

    Private Sub value7_Click(sender As Object, e As EventArgs) Handles value7.Click
        If Output.Text <> "0" Then
            Output.Text += "7"
        Else
            Output.Text = "7"
        End If

    End Sub

    Private Sub value8_Click(sender As Object, e As EventArgs) Handles value8.Click
        If Output.Text <> "0" Then
            Output.Text += "8"
        Else
            Output.Text = "8"
        End If

    End Sub

    Private Sub value9_Click(sender As Object, e As EventArgs) Handles value9.Click
        If Output.Text <> "0" Then
            Output.Text += "9"
        Else
            Output.Text = "9"
        End If

    End Sub

    Private Sub value0_Click(sender As Object, e As EventArgs) Handles value0.Click
        If Output.Text <> "0" Then
            Output.Text += "0"
        Else
            Output.Text = "0"
        End If

    End Sub

    Private Sub addition_Click(sender As Object, e As EventArgs) Handles addition.Click
        num1 = Int(Output.Text)
        num1 = Int(Output.Text)
        Output.Clear()
        add = True
    End Sub

    Private Sub minus_Click(sender As Object, e As EventArgs) Handles minus.Click
        num1 = Int(Output.Text)
        Output.Clear()
        take = True
    End Sub

    Private Sub divide_Click(sender As Object, e As EventArgs) Handles divide.Click
        num1 = Int(Output.Text)
        Output.Clear()
        divid = True
    End Sub

    Private Sub multiplication_Click(sender As Object, e As EventArgs) Handles multiplication.Click
        num1 = Int(Output.Text)
        Output.Clear()
        multiply = True
    End Sub

    Private Sub equals_Click(sender As Object, e As EventArgs) Handles equals.Click
        num2 = Int(Output.Text)
        Output.Clear()

        If add = True Then
            Answer = num1 + num2
            Output.Text = Answer

        ElseIf take = True Then
            Answer = num1 - num2
            Output.Text = Answer

        ElseIf divid = True Then
            Answer = num1 / num2
            Output.Text = Answer

        ElseIf multiply = True Then
            Answer = num1 * num2
            Output.Text = Answer
        End If
    End Sub

    Private Sub clear_all_Click(sender As Object, e As EventArgs) Handles clear_all.Click
        Output.Clear()
        num1 = num1 - num1
        num2 = num2 - num2
    End Sub

    Private Sub Output_TextChanged(sender As Object, e As EventArgs) Handles Output.TextChanged

    End Sub
End Class
