﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Output = New System.Windows.Forms.RichTextBox()
        Me.value1 = New System.Windows.Forms.Button()
        Me.value2 = New System.Windows.Forms.Button()
        Me.value3 = New System.Windows.Forms.Button()
        Me.addition = New System.Windows.Forms.Button()
        Me.value4 = New System.Windows.Forms.Button()
        Me.value7 = New System.Windows.Forms.Button()
        Me.value5 = New System.Windows.Forms.Button()
        Me.value8 = New System.Windows.Forms.Button()
        Me.value6 = New System.Windows.Forms.Button()
        Me.value9 = New System.Windows.Forms.Button()
        Me.minus = New System.Windows.Forms.Button()
        Me.divide = New System.Windows.Forms.Button()
        Me.multiplication = New System.Windows.Forms.Button()
        Me.clear_all = New System.Windows.Forms.Button()
        Me.equals = New System.Windows.Forms.Button()
        Me.value0 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Output
        '
        Me.Output.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Output.Enabled = False
        Me.Output.Font = New System.Drawing.Font("Microsoft Tai Le", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Output.Location = New System.Drawing.Point(5, 6)
        Me.Output.Name = "Output"
        Me.Output.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Output.Size = New System.Drawing.Size(276, 76)
        Me.Output.TabIndex = 0
        Me.Output.Text = ""
        '
        'value1
        '
        Me.value1.BackColor = System.Drawing.SystemColors.Menu
        Me.value1.Location = New System.Drawing.Point(5, 109)
        Me.value1.Name = "value1"
        Me.value1.Size = New System.Drawing.Size(65, 55)
        Me.value1.TabIndex = 1
        Me.value1.Text = "1"
        Me.value1.UseVisualStyleBackColor = False
        '
        'value2
        '
        Me.value2.BackColor = System.Drawing.SystemColors.Menu
        Me.value2.Location = New System.Drawing.Point(74, 109)
        Me.value2.Name = "value2"
        Me.value2.Size = New System.Drawing.Size(65, 55)
        Me.value2.TabIndex = 2
        Me.value2.Text = "2"
        Me.value2.UseVisualStyleBackColor = False
        '
        'value3
        '
        Me.value3.BackColor = System.Drawing.SystemColors.Menu
        Me.value3.Location = New System.Drawing.Point(145, 109)
        Me.value3.Name = "value3"
        Me.value3.Size = New System.Drawing.Size(65, 55)
        Me.value3.TabIndex = 3
        Me.value3.Text = "3"
        Me.value3.UseVisualStyleBackColor = False
        '
        'addition
        '
        Me.addition.BackColor = System.Drawing.SystemColors.Menu
        Me.addition.Location = New System.Drawing.Point(216, 109)
        Me.addition.Name = "addition"
        Me.addition.Size = New System.Drawing.Size(65, 55)
        Me.addition.TabIndex = 4
        Me.addition.Text = "+"
        Me.addition.UseVisualStyleBackColor = False
        '
        'value4
        '
        Me.value4.BackColor = System.Drawing.SystemColors.Menu
        Me.value4.Location = New System.Drawing.Point(5, 170)
        Me.value4.Name = "value4"
        Me.value4.Size = New System.Drawing.Size(65, 55)
        Me.value4.TabIndex = 5
        Me.value4.Text = "4"
        Me.value4.UseVisualStyleBackColor = False
        '
        'value7
        '
        Me.value7.BackColor = System.Drawing.SystemColors.Menu
        Me.value7.Location = New System.Drawing.Point(5, 231)
        Me.value7.Name = "value7"
        Me.value7.Size = New System.Drawing.Size(65, 55)
        Me.value7.TabIndex = 6
        Me.value7.Text = "7"
        Me.value7.UseVisualStyleBackColor = False
        '
        'value5
        '
        Me.value5.BackColor = System.Drawing.SystemColors.Menu
        Me.value5.Location = New System.Drawing.Point(74, 170)
        Me.value5.Name = "value5"
        Me.value5.Size = New System.Drawing.Size(65, 55)
        Me.value5.TabIndex = 7
        Me.value5.Text = "5"
        Me.value5.UseVisualStyleBackColor = False
        '
        'value8
        '
        Me.value8.BackColor = System.Drawing.SystemColors.Menu
        Me.value8.Location = New System.Drawing.Point(74, 231)
        Me.value8.Name = "value8"
        Me.value8.Size = New System.Drawing.Size(65, 55)
        Me.value8.TabIndex = 8
        Me.value8.Text = "8"
        Me.value8.UseVisualStyleBackColor = False
        '
        'value6
        '
        Me.value6.BackColor = System.Drawing.SystemColors.Menu
        Me.value6.Location = New System.Drawing.Point(145, 170)
        Me.value6.Name = "value6"
        Me.value6.Size = New System.Drawing.Size(65, 55)
        Me.value6.TabIndex = 9
        Me.value6.Text = "6"
        Me.value6.UseVisualStyleBackColor = False
        '
        'value9
        '
        Me.value9.BackColor = System.Drawing.SystemColors.Menu
        Me.value9.Location = New System.Drawing.Point(145, 231)
        Me.value9.Name = "value9"
        Me.value9.Size = New System.Drawing.Size(65, 55)
        Me.value9.TabIndex = 10
        Me.value9.Text = "9"
        Me.value9.UseVisualStyleBackColor = False
        '
        'minus
        '
        Me.minus.BackColor = System.Drawing.SystemColors.Menu
        Me.minus.Location = New System.Drawing.Point(216, 170)
        Me.minus.Name = "minus"
        Me.minus.Size = New System.Drawing.Size(65, 55)
        Me.minus.TabIndex = 11
        Me.minus.Text = "-"
        Me.minus.UseVisualStyleBackColor = False
        '
        'divide
        '
        Me.divide.BackColor = System.Drawing.SystemColors.Menu
        Me.divide.Location = New System.Drawing.Point(216, 231)
        Me.divide.Name = "divide"
        Me.divide.Size = New System.Drawing.Size(65, 55)
        Me.divide.TabIndex = 12
        Me.divide.Text = "/"
        Me.divide.UseVisualStyleBackColor = False
        '
        'multiplication
        '
        Me.multiplication.BackColor = System.Drawing.SystemColors.Menu
        Me.multiplication.Location = New System.Drawing.Point(216, 292)
        Me.multiplication.Name = "multiplication"
        Me.multiplication.Size = New System.Drawing.Size(65, 55)
        Me.multiplication.TabIndex = 13
        Me.multiplication.Text = "*"
        Me.multiplication.UseVisualStyleBackColor = False
        '
        'clear_all
        '
        Me.clear_all.BackColor = System.Drawing.SystemColors.Menu
        Me.clear_all.Location = New System.Drawing.Point(5, 292)
        Me.clear_all.Name = "clear_all"
        Me.clear_all.Size = New System.Drawing.Size(65, 55)
        Me.clear_all.TabIndex = 14
        Me.clear_all.Text = "CLEAR"
        Me.clear_all.UseVisualStyleBackColor = False
        '
        'equals
        '
        Me.equals.BackColor = System.Drawing.SystemColors.Menu
        Me.equals.Location = New System.Drawing.Point(145, 292)
        Me.equals.Name = "equals"
        Me.equals.Size = New System.Drawing.Size(65, 55)
        Me.equals.TabIndex = 15
        Me.equals.Text = "="
        Me.equals.UseVisualStyleBackColor = False
        '
        'value0
        '
        Me.value0.BackColor = System.Drawing.SystemColors.Menu
        Me.value0.Location = New System.Drawing.Point(74, 292)
        Me.value0.Name = "value0"
        Me.value0.Size = New System.Drawing.Size(65, 55)
        Me.value0.TabIndex = 16
        Me.value0.Text = "0"
        Me.value0.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.ClientSize = New System.Drawing.Size(287, 354)
        Me.Controls.Add(Me.value0)
        Me.Controls.Add(Me.equals)
        Me.Controls.Add(Me.clear_all)
        Me.Controls.Add(Me.multiplication)
        Me.Controls.Add(Me.divide)
        Me.Controls.Add(Me.minus)
        Me.Controls.Add(Me.value9)
        Me.Controls.Add(Me.value6)
        Me.Controls.Add(Me.value8)
        Me.Controls.Add(Me.value5)
        Me.Controls.Add(Me.value7)
        Me.Controls.Add(Me.value4)
        Me.Controls.Add(Me.addition)
        Me.Controls.Add(Me.value3)
        Me.Controls.Add(Me.value2)
        Me.Controls.Add(Me.value1)
        Me.Controls.Add(Me.Output)
        Me.Name = "Form1"
        Me.Text = "Calculator"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Output As RichTextBox
    Friend WithEvents value1 As Button
    Friend WithEvents value2 As Button
    Friend WithEvents value3 As Button
    Friend WithEvents addition As Button
    Friend WithEvents value4 As Button
    Friend WithEvents value7 As Button
    Friend WithEvents value5 As Button
    Friend WithEvents value8 As Button
    Friend WithEvents value6 As Button
    Friend WithEvents value9 As Button
    Friend WithEvents minus As Button
    Friend WithEvents divide As Button
    Friend WithEvents multiplication As Button
    Friend WithEvents clear_all As Button
    Friend WithEvents equals As Button
    Friend WithEvents delete As Button
    Friend WithEvents value0 As Button
End Class
